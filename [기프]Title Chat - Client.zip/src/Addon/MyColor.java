package Addon;

import java.awt.Color;

public class MyColor { //�� ������

	public static Color midNightBlue = new Color(00,33,66); 
	public static Color lightYellow = new Color(239,249,55);
	public static Color darkBlue = new Color(58,96,203);
	public static Color orange = new Color(255,84,00);
	public static Color lightOrange = new Color(247,155,60);
	public static Color navy = new Color(00,00,66);
	public static Color white = new Color(255,255,255);
	public static Color lightGray = new Color(211,211,211);
}
